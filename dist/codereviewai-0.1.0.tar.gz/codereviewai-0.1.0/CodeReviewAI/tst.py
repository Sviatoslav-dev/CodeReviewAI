import requests

url = "http://127.0.0.1:8000/review"

data = {
    "assignment_description": "This is echo server with asyncio",
    "github_repo_url": "https://github.com/Sviatoslav-dev/asyncio_echo_server",
    "candidate_level": "junior"
}

response = requests.post(url, json=data)

if response.status_code == 200:
    print("Response received successfully!")
    print("Review Result:", response.json())
else:
    print(f"Failed with status code: {response.status_code}")
    print("Error:", response.json())
